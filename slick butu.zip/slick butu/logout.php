<?php
require_once 'functions.php';
logout();
	echo  "<div><meta HTTP-EQUIV='Refresh' CONTENT='0; URL=index'></div>";
 ?>
