<?php
require_once 'functions.php';
if(!loggedIn()) {
  header('location: ./');
}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">


    <title>Butu Travels & Tours LTD</title>

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.css">

    <!-- Custom styles for this template -->
    <link href="dashboard.css" rel="stylesheet">
    <link href="logo.png" rel="icon" type="image/jpg" />
  </head>

  <body>
    <?php require_once 'navbar.php' ?>
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Clients <i class="fa fa-users"></i></h1>
          </div>

          <div class="col-lg-12 col-md-3">
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th>S/N</th>
                      <th>AGENT</th>
                      <th>GROUP</th>
                      <th>PASSPORT NO</th>
                      <th>NAME</th>
                      <th>GENDER</th>
                      <th>PHONE</th>
                      <th>ACTION</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    if(isset($_GET['page']))
                      $page = $_GET['page'];
                    if($page=='' || $page=='1'){
                      $page1 = 0;
                    } else {
                      $page1 = ($page*5)-5;
                    }
                    
                      $sn = 0;
                    $getClient = $db->query("SELECT * FROM clients WHERE regBy = '$name' LIMIT $page1,5");
                    foreach ($getClient as $key => $value) {
                      $sn ++;
                      echo "
                      <tr>
                      <td>".$sn."</td>
                      <td>".$value['agent']."</td>
                        <td>";
                          if ($value['cGroup'] != '') {
                            echo " 
                                <a href='viewgroup.php?group=".$value['cGroup']."&page=1' class='btn btn-outline-danger rounded-0'>". $value['cGroup'] ."<br> Click to View </a>
                            ";
                          } else {
                            echo "
                              No Group
                            ";
                          }
                        
                      echo "</td> <td>".$value['passport']."</td>
                        <td> " . $value['surname'] . " " . $value['gnames']. "</td>
                        <td>".$value['gender']."</td>
                        <td>".$value['phone']."</td>
                        <td width='220px'><a href='cProfile?client=".$value['id']."' class='btn btn-outline-danger rounded-0'>Profile</a> | <a href='cpay?client=".$value['id']."' class='btn btn-outline-danger rounded-0'> Payment</a></i></td>
                      </tr>
                      ";
                    }

                     ?>

                  </tbody>
                </table>
                <?php $getRowCount = $db->query("SELECT * FROM clients WHERE regBy = '$name' ");
                $a = $getRowCount->num_rows / 5;

                $a = ceil($a);
              echo "<nav class='pagination float-right'>";
                for($b=1; $b<=$a; $b++){
                ?>  
                <a class="btn btn-outline-danger rounded-0" href="vClient?page=<?php echo $b ?>"> <?php echo $b . ' '; ?> </a>
               <?php
                }
              echo "  </nav>";
                 ?>

              </div>
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>
  </body>
</html>
